YOU MUST PRINT AND READ THIS FILE BEFORE USING THE SOFTWARE!
THIS KEYBOARD WILL WORK ONLY WITH WINDOWS NT, 2000, or XP.
WINDOWS 95/98/ME USERS MUST DOWNLOAD A SPECIAL ADD-IN FILE,
AVAILABLE AT THE ATTIC GREEK WEBSITE:
http://members.aol.com/AtticGreek

STEP 1: INSTALL KEYBOARD SOFTWARE (KEYMAN 5.x).
To install the keyboard and software, run the file
GreekUnicode.exe.  

STEP 2: SELECT HOTKEYS TO TURN THE KEYBOARD ON AND OFF.
After installation, the first step is to select hotkeys:
Run "Keyman Configuration" (under Start, Programs, Tavultesoft Keyman).
(Recommended:)
Select "Alt Z" as the hotkey to turn ON the Greek keyboard.
Under the "options" tab, select "Alt X" as the "OFF" hotkey.
Then press "Apply," and "OK."

STEP 3: LOAD KEYMAN.
The next step is to load Keyman:
Run "Keyman" (under Start, Programs, Tavultesoft Keyman).
(To automatically load whenever Windows starts, right click
the Keyman icon in the lower right and select that option.)

STEP 4: TEST IN ANY UNICODE APPLICATION.
I have included the MS Word document "fonttest.doc"
for this purpose.  Use the "ON" hotkey sequence you 
chose in Step 2 and type in Greek (but see next step).

STEP 5: SELECT THE PROPER FONT (PALATINO LINOTYPE).
Make sure to have a good Unicode font selected, one
with support for all the classical Greek characters.
I recommend the font Palatino Linotype (comes with
Windows 2000/XP).  The only defects I detected with
Palatino Linotype are:
1. No lunate sigma and no lowercase digamma.
2. Capital rho with rough breathing is given a smooth breathing.
3. Only precomposed characters are fully supported.
(#3 is not an issue, since this keyboard always selects
precomposed characters.)

STEP 6: TURN THE KEYBOARD OFF.
To switch back to your normal keyboard, press the
hotkey OFF sequence you chose in Step 2.

The keyboard software to use this keyboard is not mine.
It is called Keyman.
Updates and licensing information are available at:
	http://www.tavultesoft.com/keyman/

In Windows 2000/NT/XP, you can use the keyboard with
any Unicode application, such as MS Word, Notepad, etc.
Under Windows 9x or ME, it will only work with MS Word, and
only if you install the special add-in provided on the
Attic Greek website.

Most characters are as you would expect, but note:
eta = h, theta = q, xi = c or j, chi = x, psi = y (psy).
Medial sigma is automatically converted to final sigma as appropriate.

Accent marks (select AFTER the vowel):
Perseus/Tufts Beta code system (combine as you wish): 
/ for acute, \ for grave, = for circumflex, 
] for smooth, [ for rough 
| for iota, + for diaresis
- for breve, _ for macron
` is a deadkey to pass the next character through without translation.

Hitting the same accent or breathing mark that a character already
has, will remove it. (For capital letters, the breathing mark
should be selected before other marks.)

To uninstall:
Select Uninstall under Start, Programs, Tavultesoft Keyman.

THIS SOFTWARE PROVIDED "AS IS," WITHOUT WARRANTY OF ANY KIND.
YOU MAY NOT ALTER OR REVERSE ENGINEER THIS KEYBOARD,
OR REDISTRIBUTE IN ANY ALTERED FORM WITHOUT WRITTEN PERMISSION FROM THE AUTHOR.
Text and code is copyright 2002 by Manuel A. Lopez.  All rights reserved.
Version 2.0.  Created with Keyman 5.0.112.0.  March 2002
MANUEL LOPEZ
AtticGreek@aol.com
